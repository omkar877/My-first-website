import React from "react";
import AdminHeader from "../components/AdminHeader";

function AdminHome() {
  return (
    <div className="bg-gray-100">
      <AdminHeader />
    </div>
  );
}

export default AdminHome;
